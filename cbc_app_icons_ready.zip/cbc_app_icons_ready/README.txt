# CBC App Icons

Dossier prêt à déposer sur GitHub.

## À faire

1. Upload le dossier `public/` à la racine de ton projet.
2. Copie le contenu de `index-head-snippet.html`.
3. Colle-le dans le `<head>` de ton `index.html`.

## Fichiers inclus

- `cbc_icon_1024.png`
- `cbc_icon_512.png`
- `cbc_icon_192.png`
- `apple-touch-icon.png`
- `maskable_icon.png`
- `favicon.ico`
- `favicon-32x32.png`
- `favicon-16x16.png`
- `manifest.json`
